#ifndef SIMULADOR_H
#define SIMULADOR_H

#include <stdio.h>
#include <stdlib.h>

#define MAX_FILAS 100
#define MAX_COLUMNAS 100
#define PROBABILIDAD_INFECCION 10
#define PROBABILIDAD_RECUPERACION 10
#define PROBABILIDAD_MUERTE 2 

// Estructura para representar una celda en el autómata celular
typedef struct {
    int susceptible;
    int infectado;
    int recuperado;
    int difunto;
} Cell;

// Estructura del autómata celular como una matriz de tamaño fijo
typedef struct {
    int filas;
    int columnas;
    Cell matriz[MAX_FILAS][MAX_COLUMNAS];
} AutomataCelular;

// Funciones para manejar el autómata celular
void crear_automata(AutomataCelular *ac, int filas, int columnas);
void simular_confinamiento(AutomataCelular *ac, int tiempo);
void simular_transito(AutomataCelular *ac, int tiempo);

void inicializar_poblacion(AutomataCelular *ac, int s, int i, int r, int d);

#endif // SIMULADOR_H
