#include "simulador.h"

// Crea un autómata celular de tamaño filas x columnas y lo inicializa
void crear_automata(AutomataCelular *ac, int filas, int columnas) {
    if (filas > MAX_FILAS || columnas > MAX_COLUMNAS) {
        fprintf(stderr, "Error: dimensiones exceden los límites permitidos (%d x %d).\n", MAX_FILAS, MAX_COLUMNAS);
        exit(1);
    }
    ac->filas = filas;
    ac->columnas = columnas;
    printf("Autómata creado con dimensiones %d x %d.\n", filas, columnas);
}

// Inicializa la población en cada celda del autómata
void inicializar_poblacion(AutomataCelular *ac, int s, int i, int r, int d) {
    for (int x = 0; x < ac->filas; x++) {
        for (int y = 0; y < ac->columnas; y++) {
            ac->matriz[x][y].susceptible = s;
            ac->matriz[x][y].infectado = i;
            ac->matriz[x][y].recuperado = r;
            ac->matriz[x][y].difunto = d;
        }
    }
    printf("Población inicializada en cada celda.\n");
}

// Muestra el estado actual del autómata celular
void mostrar_automata(AutomataCelular *ac) {
    for (int x = 0; x < ac->filas; x++) {
        for (int y = 0; y < ac->columnas; y++) {
            printf("Celda (%d, %d): S=%d, I=%d, R=%d, D=%d\n", x, y,
                   ac->matriz[x][y].susceptible,
                   ac->matriz[x][y].infectado,
                   ac->matriz[x][y].recuperado,
                   ac->matriz[x][y].difunto
                   );
        }
    }
}

void actualizar_estado_celda(Cell *celda) {
    int nuevos_recuperados = 0;
    int nuevos_difuntos = 0;

    for (int i = 0; i < celda->infectado; i++) {
        int prob = rand() % 100;
        if (prob < PROBABILIDAD_RECUPERACION) {
            nuevos_recuperados++;
        } else if (prob < PROBABILIDAD_RECUPERACION + PROBABILIDAD_MUERTE) {
            nuevos_difuntos++;
        }
    }

    celda->recuperado += nuevos_recuperados;
    celda->difunto += nuevos_difuntos;
    celda->infectado -= (nuevos_recuperados + nuevos_difuntos);

    if (celda->infectado < 0) celda->infectado = 0;
}

void simular_confinamiento(AutomataCelular *ac, int tiempo) {
    printf("estado inicial automata \n");
    mostrar_automata(ac);
    printf("\n");
    printf("Simulando confinamiento por %d pasos de tiempo.\n", tiempo);
    for (int t = 0; t < tiempo; t++) {
        for (int x = 0; x < ac->filas; x++) {
            for (int y = 0; y < ac->columnas; y++) {
                actualizar_estado_celda(&ac->matriz[x][y]);
            }
        }
        printf("Paso %d completado en confinamiento.\n", t + 1);
        mostrar_automata(ac);
        printf("\n");
    }
}

//función construida con chat GPT
void contagiar_vecinos(AutomataCelular *ac, int x, int y) {
    int dx[] = {-1, 1, 0, 0, -1, -1, 1, 1};
    int dy[] = {0, 0, -1, 1, -1, 1, -1, 1};

    for (int i = 0; i < 8; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && nx < ac->filas && ny >= 0 && ny < ac->columnas) {
            Cell *vecino = &ac->matriz[nx][ny];
            if (vecino->susceptible > 0 && (rand() % 100) < 10) {
                vecino->infectado += vecino->susceptible;
                vecino->susceptible = 0;
            }
        }
    }
}


void simular_transito(AutomataCelular *ac, int tiempo) {
    printf("Simulando tránsito por %d pasos de tiempo.\n", tiempo);
    for (int t = 0; t < tiempo; t++) {
        for (int x = 0; x < ac->filas; x++) {
            for (int y = 0; y < ac->columnas; y++) {
                Cell *celda = &ac->matriz[x][y];
                if (celda->infectado > 0) {
                    contagiar_vecinos(ac, x, y);  // Contagiar a los vecinos
                    actualizar_estado_celda(celda);  // Actualizar el estado de la celda
                }
            }
        }
        printf("Paso %d completado en tránsito.\n", t + 1);
        mostrar_automata(ac);
        printf("\n");
    }
}
